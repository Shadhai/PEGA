#!/usr/bin/env python3
"""
CINT-70 Industrial evaluation (150 tasks) — validation only, no LLM.
Usage:
  python run_industrial_eval.py
  python run_industrial_eval.py --ablation
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.graph.queries import ConstraintQueries
from src.validator.kinematics import KinematicsValidator
from src.validator.reach import check_reach

ABLATIONS = [
    ("full",            {}),
    ("no_graph",        {"use_graph": False}),
    ("no_kinematics",   {"use_kinematics": False}),
    ("no_trajectory",   {"use_trajectory": False}),
    ("no_force_check",  {"use_force_check": False}),
    ("graph_only",      {"use_kinematics": False, "use_force_check": False, "use_trajectory": False}),
    ("kinematics_only", {"use_graph": False, "use_force_check": False, "use_trajectory": False}),
]


class IndustrialValidator:
    def __init__(self, ablation=None):
        self.ablation = {
            "use_graph": True,
            "use_kinematics": True,
            "use_trajectory": True,
            "use_force_check": True,
        }
        if ablation:
            self.ablation.update(ablation)

        db_path = "data/graph_db_industrial.kuzu"
        p = Path(db_path)
        if p.exists():
            if p.is_dir():
                import shutil
                shutil.rmtree(p)
            else:
                p.unlink()

        self.graph = ConstraintQueries(db_path=db_path, domain="industrial")
        self.kinematics = KinematicsValidator()
        self._last_pos = None
        self.domain = "industrial"

    def validate_plan(self, plan):
        violations = []
        all_passed = True
        self._last_pos = None

        for step in plan:
            step_id = step.get("step_id", 0)

            joint = step.get("joint")
            angle = step.get("target_angle_deg")
            if self.ablation["use_graph"] and joint is not None and angle is not None:
                try:
                    res = self.graph.check_joint_limits(joint, float(angle))
                    if not res.get("passed", True):
                        all_passed = False
                        violations.append({
                            "step_id": step_id, "type": "joint_limit",
                            "message": res.get("violation", "joint limit"),
                            "severity": res.get("severity", 0.9),
                        })
                except Exception:
                    pass

            tool = step.get("tool_name")
            force = step.get("contact_force_n")
            if self.ablation["use_force_check"] and tool is not None and force is not None:
                try:
                    res = self.graph.check_tool_force(tool, float(force))
                    if not res.get("passed", True):
                        all_passed = False
                        violations.append({
                            "step_id": step_id, "type": "force",
                            "message": res.get("violation", "force limit"),
                            "severity": res.get("severity", 0.9),
                        })
                except Exception:
                    pass

            coords = step.get("target_coordinates")
            if self.ablation["use_kinematics"] and coords is not None:
                res = check_reach(coords, domain=self.domain)
                if not res["passed"]:
                    all_passed = False
                    violations.append({
                        "step_id": step_id, "type": "kinematics",
                        "message": res["violation"],
                        "severity": res["severity"],
                    })

            if self.ablation["use_graph"] and coords is not None:
                try:
                    end = [float(coords[0]), float(coords[1]), float(coords[2])]
                    points = [end]
                    if (self.ablation["use_trajectory"]
                        and step.get("action") == "move_to"
                        and self._last_pos is not None):
                        try:
                            points = self.kinematics.sample_trajectory(
                                self._last_pos, end, n_samples=15
                            )
                        except Exception:
                            points = [end]

                    for idx, wp in enumerate(points):
                        is_end = (idx == len(points) - 1)
                        if is_end:
                            res = self.graph.check_collision(wp[0], wp[1], wp[2])
                        else:
                            try:
                                res = self.graph.check_collision_trajectory(wp[0], wp[1], wp[2])
                            except Exception:
                                res = self.graph.check_collision(wp[0], wp[1], wp[2])
                        if not res.get("passed", True):
                            all_passed = False
                            violations.append({
                                "step_id": step_id, "type": "collision",
                                "message": res.get("violation", "collision"),
                                "severity": res.get("severity", 0.85),
                            })
                            break
                    if step.get("action") == "move_to":
                        self._last_pos = end
                except Exception:
                    pass

        return {"all_checks_passed": all_passed, "violations": violations}


def load_tasks():
    with open("data/extracted/task_library_industrial.json") as f:
        data = json.load(f)
    return data["tasks"] if isinstance(data, dict) else data


def run_config(name, ablation, tasks):
    v = IndustrialValidator(ablation=ablation)
    tp = fp = fn = tn = 0
    for task in tasks:
        expected = bool(task.get("expected_safe", True))
        plan = (
            task.get("ground_truth_plan")
            or task.get("adversarial_plan")
            or task.get("plan")
            or []
        )
        result = v.validate_plan(plan)
        approved = bool(result["all_checks_passed"])
        if not expected:
            if not approved:
                tp += 1
            else:
                fn += 1
        else:
            if approved:
                tn += 1
            else:
                fp += 1

    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    uar = fn / (tp + fn) if (tp + fn) else 0.0
    return {
        "config": name,
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "uar": round(uar, 4),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ablation", action="store_true")
    args = parser.parse_args()

    tasks = load_tasks()
    print(f"Loaded {len(tasks)} industrial tasks")

    configs = ABLATIONS if args.ablation else [("full", {})]
    results = []
    for name, overrides in configs:
        print(f"Running {name}...")
        r = run_config(name, overrides, tasks)
        results.append(r)
        print(f"  {name}: F1={r['f1']:.4f}  UAR={r['uar']:.4f}  TP={r['tp']} FN={r['fn']} FP={r['fp']} TN={r['tn']}")

    os.makedirs("logs/benchmarks", exist_ok=True)
    out = "logs/benchmarks/industrial_ablation.json" if args.ablation else "logs/benchmarks/industrial_full.json"
    with open(out, "w") as f:
        json.dump(results if args.ablation else results[0], f, indent=2)
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
