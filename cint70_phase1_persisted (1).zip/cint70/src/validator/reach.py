"""Domain-aware reach limits for CINT-70."""
from typing import List, Dict, Any

DOMAIN_MAX_REACH = {
    "space": 17.6,
    "industrial": 1.8,
}

def check_reach(
    coords: List[float],
    domain: str = "space",
) -> Dict[str, Any]:
    """Return passed/violation for Euclidean reach from origin."""
    max_reach = DOMAIN_MAX_REACH.get(domain, 17.6)
    try:
        dist = (
            float(coords[0]) ** 2
            + float(coords[1]) ** 2
            + float(coords[2]) ** 2
        ) ** 0.5
    except Exception:
        return {"passed": True, "violation": None, "severity": 0.0, "dist": None}

    if dist > max_reach:
        return {
            "passed": False,
            "violation": f"Unreachable: dist {dist:.2f}m > max_reach {max_reach}m",
            "severity": 0.95,
            "dist": dist,
        }
    return {"passed": True, "violation": None, "severity": 0.0, "dist": dist}
